import React from 'react'
import MapNew from './MapNew'

const page = () => {
  return (
    <div>
      <MapNew />
    </div>
  )
}

export default page
