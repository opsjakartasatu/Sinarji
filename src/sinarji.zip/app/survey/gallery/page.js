import React from 'react'
import Gallery from './Gallery';

const page = async () => {
    return (
        <>
            <Gallery />
        </>
    )
}

export default page