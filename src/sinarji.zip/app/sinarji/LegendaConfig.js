// LegendConfig.js

const legends = {
  Elevasi: [
    {
      title: "Di bawah laut",
      gradient: "#5D9FF1",
    },
    {
      title: "Di atas laut",
      gradient: "linear-gradient(to right, #000000, #ffffff)", // hitam → putih
    },
  ],
  "Penurunan Tanah": [
    {
      title: "Laju Penurunan",
      gradient: "linear-gradient(to right, #ffff00, #ff0000)", // kuning → merah
      labels: ["Rendah", "Tinggi"],
    },
  ],
};

export default legends;
