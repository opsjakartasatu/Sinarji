// SkenarioTanpaTanggul.js

const url = "https://sinarji-geo.dsdajakarta.id/geoserver/fews/wms?";

const skenariotanpatanggulLayers = [];
for (let year = 2007; year <= 2024; year++) {
  skenariotanpatanggulLayers.push({
    id: `robnodike-${year}`,
    name: `Rob_NoDike_${year}`,
    title: `Tanpa Tanggul - ${year}`,
    // visible: year === 1975, // default aktif hanya 1975
    opacity: 0.75,
    source: "fews", // penting untuk ambil GEOSERVER_URL_FEWS
  });
}

export { url, skenariotanpatanggulLayers };
