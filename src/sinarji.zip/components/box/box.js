import styles from "../page.module.css"

export default function Home() {
  return (
    <div className={styles.BoxContainerBox}>
      <div className={styles.BoxContentBox}>

      </div>
    </div>
  )
}
