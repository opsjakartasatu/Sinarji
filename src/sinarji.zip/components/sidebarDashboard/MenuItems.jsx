const Menuitems = [
  {
    id: 1,
    title: "Dashboard",
    href: "/",
  },
  {
    id: 2,
    title: "Typography",
    href: "/utilities/typography",
  },
  {
    id: 3,
    title: "Shadow",
    href: "/utilities/shadow",
  },
  {
    id: 6,
    title: "Icons",
    href: "/icons",
  },
  {
    id: 7,
    title: "Sample Page",
    href: "/sample-page",
  },
];

export default Menuitems;
